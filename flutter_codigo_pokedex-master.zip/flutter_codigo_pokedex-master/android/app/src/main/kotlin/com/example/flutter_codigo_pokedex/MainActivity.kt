package com.example.flutter_codigo_pokedex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
